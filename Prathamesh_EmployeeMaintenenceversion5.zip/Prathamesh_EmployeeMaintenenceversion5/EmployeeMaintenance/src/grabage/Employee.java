package grabage;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity(name="employee")
@Table(name="EMPLOYEE")
@SequenceGenerator(name="emp_generate",sequenceName="hibernate_sequence", allocationSize=1,initialValue=1000 )
public class Employee implements Serializable{


	private static final long serialVersionUID = 1L;
	
	//Data Members going to be used 
	private String empId;
	private String empFname;
	private String empLname;
	private Date empDateOfBirth;
	private Date empDateOfJoining;
	private int empDeptId;
	private String deptName;
	private String empGrade;
	private String empDesignation;
	private int empBasic;
	private String empGender;
	private String empMaritalStatus;
	private String empHomeAddress;
	private String empContactNo;
	
	//Associated data members
	private Department dept;
	private Grade grade;
	//private UserMaster user;
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Id
	@GenericGenerator(name = "emp_generate", strategy = "Mypackage.StringSequenceGenerator")
	@GeneratedValue(generator="emp_generate",strategy=GenerationType.SEQUENCE)
	@Column(name="EMP_ID")
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	@Column(name="EMP_FIRST_NAME")
	public String getEmpFname() {
		return empFname;
	}
	public void setEmpFname(String empFname) {
		this.empFname = empFname;
	}
	
	@Column(name="EMP_LAST_NAME")
	public String getEmpLname() {
		return empLname;
	}
	public void setEmpLname(String empLname) {
		this.empLname = empLname;
	}
	
	@Column(name="EMP_DATE_OF_BIRTH")
	public Date getEmpDateOfBirth() {
		return empDateOfBirth;
	}
	public void setEmpDateOfBirth(Date empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}
	
	@Column(name="EMP_DATE_OF_JOINING")
	public Date getEmpDateOfJoining() {
		return empDateOfJoining;
	}
	public void setEmpDateOfJoining(Date empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}
	
	@Column(name="EMP_DESIGNATION")
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	
	
	@Column(name="EMP_BASIC")
	public int getEmpBasic() {
		return empBasic;
	}
	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}
	
	@Column(name="EMP_GENDER")
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	
	@Column(name="EMP_MARITAL_STATUS")
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	
	@Column(name="EMP_HOME_ADDRESS")
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	
	@Column(name="EMP_CONTACT_NUM")
	public String getEmpContactNo() {
		return empContactNo;
	}
	public void setEmpContactNo(String empContactNo) {
		this.empContactNo = empContactNo;
	}
	
	@Column(name="EMP_DEPT_ID")
	public int getEmpDeptId() {
		return empDeptId;
	}
	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}
	
	@Column(name="EMP_GRADE")
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="empDeptId")
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="empGrade")
	public Grade getGrade() {
		return grade;
	}
	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	/*@OneToOne
	@JoinColumn(name="EMP_ID")
	public UserMaster getUser() {
		return user;
	}
	public void setUser(UserMaster user) {
		this.user = user;
	}*/
	
	@Transient
	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFname=" + empFname
				+ ", empLname=" + empLname + ", empDateOfBirth="
				+ empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining
				+ ", empDeptId="  + ", empGrade=" 
				+ ", empDesignation=" + empDesignation + ", empBasic="
				+ empBasic + ", empGender=" + empGender + ", empMaritalStatus="
				+ empMaritalStatus + ", empHomeAddress=" + empHomeAddress
				+ ", empContactNo=" + empContactNo + ", dept=" + dept
				+ ", grade=" + grade + "]";
	}
	
}
