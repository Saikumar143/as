package com.cg.empSystem.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;

@Controller
public class EmployeeController {
	
	private EmployeeService service;
	private List<String> deptName; 
    private List<String> gender;
    private List<String> grade;
    private List<String> maritalStatus;
	
	@Resource(name="empService")
	public void setEmpService(EmployeeService service){
		this.service= service;
	}
	
	//use of @PostConstruct to populate data to form
	@PostConstruct
	public void initialize() throws EmployeeException{
		deptName = service.getDeptname();
		
		gender = new ArrayList<String>();
		gender.add("Male");
		gender.add("Female");
		
		grade = new ArrayList<String>();
		grade.add("M1");
		grade.add("M2");
		grade.add("M3");
		grade.add("M4");
		grade.add("M5");
		grade.add("M6");
		grade.add("M7");
		
		maritalStatus = new ArrayList<String>();
		maritalStatus.add("Single");
		maritalStatus.add("Married");
		maritalStatus.add("Divorced");
		maritalStatus.add("Separated");
		maritalStatus.add("Widowed ");
	}
	
	@RequestMapping("/login.do")
	public ModelAndView login(){
		ModelAndView model=new ModelAndView("login");
		
		return model;
	}
	
	//dispatch to welcome page
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	
	//dispatch to add employee form
	@RequestMapping("addEmpForm")
	public ModelAndView addEmpForm(){
		ModelAndView model = new ModelAndView("addEmployee");
		model.addObject("empDetails", new Employee());
		model.addObject("deptNmList", deptName);
		model.addObject("genderList", gender);
		model.addObject("gradeList", grade);
		model.addObject("maritalStatusList", maritalStatus);
		return model;
	}
	
	@RequestMapping("addEmp")
	public ModelAndView successAdd(@ModelAttribute("empDetails") @Valid Employee emp,BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model = new ModelAndView("addEmployee");
			model.addObject("empDetails", emp);
			model.addObject("deptNmList", deptName);
			model.addObject("genderList", gender);
			model.addObject("gradeList", grade);
			model.addObject("maritalStatusList", maritalStatus);
			return model;
		}
		try {
			UserMaster userDetails = service.addUser(emp);
			model.setViewName("success");
			model.addObject("userDetails", userDetails);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("msg", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("getChangedPassForm")
	public ModelAndView getEmployeeIdForm(){
		ModelAndView model = new ModelAndView("getChangedPassForm");
		model.addObject("userDetails", new UserMaster());
		return model;
	}
	
	@RequestMapping("changePass")
	public ModelAndView getChangedPass(@ModelAttribute("userDetails") @Valid UserMaster user,@RequestParam("newPass") String newPass,@RequestParam("confirmPass") String confirmPass,BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model = new ModelAndView("getChangedPassForm");
			model.addObject("userDetails", user);
			return model;
		}
		try {
			UserMaster usermstr = service.getUserDetails(user.getUserId());
			if(user.getUserPassword().equals(usermstr.getUserPassword())){
				if(newPass.equals(confirmPass)){
					usermstr.setUserPassword(newPass);
					UserMaster usermstrnew = service.changePassword(usermstr);
					System.out.println("After Change password:"+usermstrnew);
					model.setViewName("successChangePass");
					model.addObject("userDetails", usermstrnew);
				}else{
					model.setViewName("getChangedPassForm");
					model.addObject("confirmPassErr", "Confirm Password And New password should be same");
				}
			}else{
				model.setViewName("getChangedPassForm");
				model.addObject("oldPassErr", "Old Password is not Correct");
			}
			
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("msg", "Password change failed"+e.getMessage());
		}
		return model;
	}

	@RequestMapping("/deleteForm.do")
	public ModelAndView getLoginPage() {
		ModelAndView model = new ModelAndView("deleteForm");
		model.addObject("emp",new Employee());
		return model;
	}
	
	@RequestMapping("/deleteEmployee.do")
	public ModelAndView deleteEmployeePage(@ModelAttribute("empDetails") @Valid Employee emp,BindingResult result) throws SQLException {
		String empId=emp.getEmpId();
		ModelAndView model=new ModelAndView();
		try {
			service.removeEmployeeDetails(empId);
			model.setViewName("employeeDeleted");
			model.addObject("employee",empId);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("errorMsg","Record Insertion failed: "+e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/listAllEmps.do")
	public ModelAndView listAllTrainees(){
		
		ModelAndView model= null;
		try {
			List<Employee> emp = service.showAllEmployee();
			model = new ModelAndView("allEmpDetails");
			model.addObject("allEmpDetails", emp);
		} catch (EmployeeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	//starting of update
			@RequestMapping("update.do")
			public ModelAndView updateForm()
			{
				ModelAndView model=new ModelAndView();
				model.setViewName("Id");
				return model;
			}
			
			//finding data based on employee id 
			@RequestMapping("searchEmployeeOnId.do")
			public ModelAndView searchId(@RequestParam("Id")String id) throws EmployeeException
			{
				ModelAndView model=new ModelAndView();
				Employee empl=service.searchId(id);
				
				Department dept=service.getDeptName(empl.getEmpDeptId());
				System.out.println(dept);
				System.out.println(empl);
				System.out.println(dept.getDeptName());
				model.addObject("employee",empl);
				model.addObject("deptNmList", deptName);
				model.addObject("genderList", gender);
				model.addObject("gradeList", grade);
				model.addObject("maritalStatusList", maritalStatus);
				model.addObject("deptname", dept.getDeptName());
				model.setViewName("Update");
				return model;
			}
			
			//update employee
			@RequestMapping("updateEmp.do")
			public ModelAndView updateEmployee(@ModelAttribute("employee")Employee emp) throws EmployeeException
			{
				ModelAndView model=new ModelAndView();
				System.out.println(emp);
				System.out.println(emp.getEmpDeptId());
			 boolean check =service.updateEmp(emp);
				model.setViewName("successUpdate");
				model.addObject("empl", emp);
				return model;
			}
//End of Update Data
	
	@RequestMapping("/searchByFirstName.do")
	public ModelAndView searchByFirstNameForm(){
		
		ModelAndView model= null;
		model = new ModelAndView("searchEmployeeOnFirstName");
		return model;
		
	}
	
	@RequestMapping("/searchEmployeeOnFirstName.do")
	public ModelAndView searchEmployeeOnFirstName(@RequestParam("empFname") String firstName){
		
		ModelAndView model= null;
		try { 
			List<Employee> emp = service.searchEmployeeOnFirstName(firstName);
			model = new ModelAndView("allEmpDetailsByFirstName");
			model.addObject("allEmpDetailsByFirstName", emp);
		} catch (EmployeeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	@RequestMapping("/searchByLastName.do")
	public ModelAndView searchByLastNameForm(){
		
		ModelAndView model= null;
		model = new ModelAndView("searchEmployeeOnLastName");
		return model;
		
	}
	
	@RequestMapping("/searchEmployeeOnLastName.do")
	public ModelAndView searchEmployeeOnLastName(@RequestParam("empLname") String lastName){
		
		ModelAndView model= null;
		try { 
			List<Employee> emp = service.searchEmployeeOnLastName(lastName);
			model = new ModelAndView("allEmpDetailsByLastName");
			model.addObject("allEmpDetailsByLastName", emp);
		} catch (EmployeeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	@RequestMapping("/searchByMaritalStatus.do")
	public ModelAndView searchByMaritalStatusForm(){
		
		ModelAndView model= null;
		model = new ModelAndView("searchByMaritalStatus");
		model.addObject("martialStatusList", maritalStatus);
		return model;
		
	}
	
	@RequestMapping("/searchEmployeeOnMaritalStatus.do")
	public ModelAndView searchEmployeeByMaritalStatus(@RequestParam("martialStatus") String martialStatus){
		
		ModelAndView model= null;
		try { 
			List<Employee> emp = service.searchEmployeeOnMaritalStatus(martialStatus);
			model = new ModelAndView("allEmpDetailsByMartialStatus");
			model.addObject("allEmpDetailsByMartialStatus", emp);
		} catch (EmployeeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	
	
	
	@RequestMapping("/authenticate.do")
	public ModelAndView isValid(@RequestParam("userName") String userName,@RequestParam("password")String userPassword) throws EmployeeException
	{System.out.println(userName+userPassword);
		ModelAndView model=new ModelAndView();
		int result=service.isValid(userName, userPassword);
		System.out.println(result);
		if(result==1)
		{
			model.setViewName("welcome");
		}
		else if(result==2)
		{
			model.setViewName("employee");
		}
		else
		{
			model.setViewName("login");
		}
		return model;
		
	}
	
	@RequestMapping("getGrade.do")
	public ModelAndView GradePage()
	{
		ModelAndView model=new ModelAndView();
		model.setViewName("grade");
		return model;
	}
	@RequestMapping("gradeList.do")
	public ModelAndView gradeList(@RequestParam("grade1") String grade ) throws EmployeeException
	{
		ModelAndView model=new ModelAndView();
		List<Employee> emplist=service.SearchGrade(grade);
		List<Grade> grades=service.getData(grade);
		System.out.println(emplist);
		System.out.println(grades);
		model.setViewName("gradelist");
		model.addObject("emplist",emplist);
		model.addObject("gradelist",grades);
		return model;
	}
	
	@RequestMapping("searchOnNameDropDown.do")
	public ModelAndView addSearchOnname() {
		ModelAndView model = new ModelAndView("searchEmployeeOnDepartmentname");

		model.addObject("deptNmList", deptName);
		return model;
	}

	@RequestMapping("searchOnDeptName.do")
	public ModelAndView depTname(@RequestParam("departmentName") String deptname) throws EmployeeException {
		System.out.println("in search on name");
		List<Employee> employee = service.searchEmployeeOnDeptName(deptname);
		System.out.println(employee);

		ModelAndView model = new ModelAndView("allEmployeeByDepartmentName");

		model.addObject("departmentName", deptname);

		model.addObject("employeeList", employee);
		return model;

	}

	

}
